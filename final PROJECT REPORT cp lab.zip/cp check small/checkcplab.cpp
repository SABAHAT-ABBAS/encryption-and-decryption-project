#include <iostream>  //input output library
#include <fstream>  //library for file handling
#include <string>   //library for strings
using namespace std;

void Encrypt(string& data);
void Decrypt(string& data);

int main() {
    while (1)  //loop so that user can do as many encryption and decryption as they want
    {
        int option;
        string data;
        cout << "*** Welcome to the program of encryption and decryption of data *** " << endl;
        cout << "Select option: " << endl;
        cout << "1: Encrypt from console input" << endl;  // users can encrypt and decrypt data by giving input on console
        cout << "2: Decrypt from console input" << endl;
        cout << "3: Encrypt from file" << endl;  //user can encrypt and decryppt text files also
        cout << "4: Decrypt from file" << endl;
        cout << "5: Exit" << endl;

        cin >> option;

        switch (option) {
        case 1:
            cout << "Enter data: " << endl;
            cin.ignore(); // Ignore the previous newline character in the input buffer
            getline(cin, data);
            Encrypt(data);
            break;
        case 2:
            cout << "Enter data: " << endl;
            cin.ignore(); // Ignore the previous newline character in the input buffer
            getline(cin, data);
            Decrypt(data);
            break;
        case 3:
        {
            string filename;
            cout << "Enter file name to encrypt: ";
            cin >> filename;   // user is suppose to enter the valid text file name to encrypt it
            ifstream inputFile(filename);
            if (inputFile.is_open()) {
                getline(inputFile, data);
                Encrypt(data);
                inputFile.close();
            }
            else {
                cout << "Unable to open file." << endl;
            }
        }
        break;
        case 4:
        {
            string filename;
            cout << "Enter file name to decrypt: ";
            cin >> filename;    // user is suppose to enter the valid text file name to decrypt it
            ifstream inputFile(filename);
            if (inputFile.is_open()) {
                getline(inputFile, data);
                Decrypt(data);
                inputFile.close();
            }
            else {
                cout << "Unable to open file." << endl;
            }
        }
        break;
        case 5:
            return 0;
        default:
            cout << "Wrong option." << endl;
            break;
        }

        cout << endl;
    }
    return 0;
}

void Encrypt(string& data)
{
    //fnction of encryption of data
    cout << "Encrypting..." << endl;
    for (int i = 0; i < data.length(); ++i) {
        // Shift each letter by 4 positions
        if ((data[i] >= 'a' && data[i] <= 'z')) {
            data[i] = 'a' + (data[i] - 'a' + 4) % 26;
        }
        else if ((data[i] >= 'A' && data[i] <= 'Z')) {
            data[i] = 'A' + (data[i] - 'A' + 4) % 26;
        }
    }
    cout << "Encrypted data: " << data << endl; //output will be encrypted data
}

void Decrypt(string& data)
{
    //function of decryption of data
    cout << "Decrypting..." << endl;
    for (int i = 0; i < data.length(); ++i) {
        // Shift each letter back by 4 positions
        if ((data[i] >= 'a' && data[i] <= 'z')) {
            data[i] = 'a' + (data[i] - 'a' + 22) % 26;
        }
        else if ((data[i] >= 'A' && data[i] <= 'Z')) {
            data[i] = 'A' + (data[i] - 'A' + 22) % 26;
        }
    }
    cout << "Decrypted data: " << data << endl;    //output will be decrypted data
}
